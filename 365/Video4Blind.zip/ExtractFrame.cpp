#include "ExtractFrame.h"
#include "stdafx.h"

void ExtractFrameFromVideo(string videoName){
	VideoCapture cap=VideoCapture(videoName.c_str());
	Mat img;
	if (cap.isOpened())
	{
		int i=0,fps=cap.get(CV_CAP_PROP_FPS);
		cap>>img;
		while(i<cap.get(CV_CAP_PROP_FRAME_COUNT)){
			imshow("Video Frames",img);
			imageToAudio(FrameConvert(img));

			//break if Esc is pressed
			if (cvWaitKey(1000)== 27) break;
			//skip the frames for 1 second
			else
			{
				for (int m = 0; m < fps; m++)
				{
					cap>>img;
					i++;
				}
			}
		} 
		cap.release();
	}
	else
		cout<<"Failed to open video.\n";
}