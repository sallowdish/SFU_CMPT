#include "ImageToAudio.h"

void ExtractFrameFromVideo(string videoName);