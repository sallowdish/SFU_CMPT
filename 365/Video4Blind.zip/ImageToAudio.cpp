#include "FrameConvert.h"
#include "stdafx.h"
#include "sound.h"
#include "math.h"

typedef unsigned char BYTE;
typedef char* LPSTR;

int Fs=8000;
int N=500;

float* initializeFrequence(){

	float *freq=new float[64];
	freq[32]=440.0;
	for (int m = 33; m < 64; m++)
	{
		freq[m]=freq[m-1]*(float)pow(2,1.0/12.0);
	}
	for (int m = 31; m >=0; m--)
	{
		freq[m]=freq[m+1]*(float)pow(2,-1.0/12.0);
	}
	return freq;
}

void imageToAudio(vector< vector<double> > im){
	float *freq =initializeFrequence();
	DWORD Fs=8000;
	int N=500;
	float* tt=new float[N];

	for(int i=0;i<N;i++)
	{
		tt[i]=(float)i/(float)Fs;
	}

	//generate the chord
	for (int col = 0; col < 64; col++)
	{
		//signal=Zeros[N,1]
		float* signal=new float[N];
		for(int m=0;m<N;m++)
		{
			signal[m]=0;
		}
		for (int row = 0; row < 64; row++)
		{
			int index=63-row;
			//ss = sin(2*pi*freq(m)* tt );
			float* ss=new float[N];
			for (int m = 0; m < N; m++)
			{
				ss[m]=(float)sin(2*3.1415926*freq[index]*tt[m]);
			}
			//signal = signal + im(row,col) * ss;
			for (int m = 0; m < N; m++)
			{
				signal[m]=signal[m]+(float)im[row][col]*ss[m];
			}
			delete []ss;
		}
		//signal = signal / 64;
		for (int m = 0; m < N; m++)
		{
			signal[m]=signal[m]/64;
		}



		//sound(signal, Fs);
		BYTE* data=new BYTE[N];
		for(int i=0;i<N;i++)
		{
			data[i]=(BYTE)(signal[i]+128.f);
		}


		Sound::writeAudioBlock((LPSTR)data);
		delete []data;
		delete []signal;
	}
	delete []tt;
	delete []freq;
		
}

//int main(){
//	Mat img=imread("D:\\OpenCV\\samples\\cpp\\lena.jpg");
//	imageToAudio(FrameConvert(img));
//	waitKey();
//	return 0;
//}