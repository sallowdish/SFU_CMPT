#include "FrameConvert.h"
#include "stdafx.h"

vector< vector<double> > FrameConvert(Mat img){
	vector< vector<double> > res(64,vector<double>(64,0));
	Mat imgGray;
	cvtColor(img,imgGray,CV_RGB2GRAY);
	if(imgGray.data){
		resize(imgGray,imgGray,Size(64,64),0,0,INTER_CUBIC);
		//imshow("gray",imgGray);
		for(int j=0;j<imgGray.rows;j++) 
		{
			for (int i=0;i<imgGray.cols;i++)
			{   
				uchar pix=imgGray.at<uchar>(j,i);
				double temp=(double((int)pix)/255);
				double value=int(temp*15)/(double)15;
				res[j][i] = value; //change the resolution
				//cout<<res[j][i]<<endl;
			}
		}
		imshow("After Effect",imgGray);
	}
	return res;
}

