#include "FrameConvert.h"
#include<vector>
using namespace std;



float* initializeFrequence();
void imageToAudio(vector< vector<double> > img);